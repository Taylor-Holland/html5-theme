<?php
/**
 * Template Name: Test
 */
get_header(); ?>

<main>

	<!-- section -->


		<div class="banner">
			<img src="<?php the_field('banner'); ?>" />

				<div class="black-button">
					<a href="<img src="<?php the_field('button_link'); ?>" ">
						<?php the_field('button_text'); ?>
					</a>

				</div>
		</div>

		<br><br>

		<section>
				<div class="WC-features">
					<a href="shop-page.html">
					<div class="feature">
						<div class="features-button">
							<h5>JACKETS</h5>
						</div>
						<img src="<?php the_field('feature1'); ?>"/>
						</div>
						</a>
							<a href="shop-page.html">
						<div class="feature">
								<div class="features-button"> <h5>ARRIVALS</h5> </div>
						 <img src="<?php the_field('feature2'); ?>"/>
							</div>
							</a>
								<a href="shop-page.html">
							<div class="feature">
									<div class="features-button"> <h5>SWIMSUITS</h5> </div>
								<img src="<?php the_field('feature3'); ?>"/>
								</div>
								</a>
				</div>
			</section>
				<br><br>
				<div class="blog-post">
					<br>
					<h3>#MYTORRID</h3>
					<p>See How The Torrid Community Shows Off Their Curves On Our Blog</p>

					<div class="blog-pic-container">
						<img src="<?php the_field('blogpic1'); ?>"/>
						<img src="<?php the_field('blogpic2'); ?>"/>
						<img src="<?php the_field('blogpic3'); ?>"/>
						<img src="<?php the_field('blogpic4'); ?>"/>
						<img src="<?php the_field('blogpic5'); ?>"/>
						<img src="<?php the_field('blogpic6'); ?>"/>

									</div>
								</div>
	<!-- /section -->
</main>

<?php get_footer(); ?>
