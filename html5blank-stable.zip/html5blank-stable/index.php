<?php get_header(); ?>

	<main role="main">
		<!-- section -->
		<section>

			<h1><?php _e( 'Latest Posts', 'html5blank' ); ?></h1>

			<?php get_template_part('loop'); ?>

			<?php get_template_part('pagination'); ?>

			<main>
			  <div class="banner">
			
			<a href="shop-page.html">
			  <div class="black-button">
			  <h4>NEW ARRIVALS</h4>
			</div>
			</a>
			  </div>
			  <br><br>
			<section>
			    <div class="WC-features">
			      <a href="shop-page.html">
			      <div class="feature">
			        <div class="features-button"> <h5>JACKETS</h5> </div>
			       <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/torrid-sailor-moon-post12.jpg">
			        </div>
			        </a>
			          <a href="shop-page.html">
			        <div class="feature">
			            <div class="features-button"> <h5>ARRIVALS</h5> </div>
			         <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/c1-plus-jpg.jpg">
			          </div>
			          </a>
			            <a href="shop-page.html">
			          <div class="feature">
			              <div class="features-button"> <h5>SWIMSUITS</h5> </div>
			            <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/Floral-Stripe-High-Neck-Bikini-Top-Torrid.jpg">
			            </div>
			            </a>
			    </div>
			  </section>
			    <br><br>
			    <div class="blog-post">
			      <br>
			      <h3>#MYTORRID</h3>
			      <p>See How The Torrid Community Shows Off Their Curves On Our Blog</p>

			      <div class="blog-pic-container">
			        <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/wc-blogpic5.jpg">
			          <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/wc-blogpic2.jpg">
			            <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/wc-blogpic3.jpg">
			              <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/wc-blogpic4.jpg">
			                <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/wc-blogpic6.jpg">
			                <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/wc-blogpic1.jpg">
			              </div>
			            </div>


			</main>


		</section>
		<!-- /section -->
	</main>

<?php get_sidebar(); ?>

<?php get_footer(); ?>
